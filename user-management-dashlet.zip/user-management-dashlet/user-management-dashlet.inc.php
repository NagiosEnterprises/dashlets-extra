<?php
//
// Dashlet to fetch, display, and add users via Nagios XI API
//

include_once(dirname(__FILE__).'/../dashlethelper.inc.php');

// Run initiation
user_management_dashlet_init();

function user_management_dashlet_init()
{
    $name = "user_management_dashlet";

    $args = array(
        DASHLET_NAME => $name,
        DASHLET_VERSION => "6.0.0",
        DASHLET_DATE => "03/25/2025",
        DASHLET_AUTHOR => "Nagios Enterprises LLC",
        DASHLET_DESCRIPTION => _("Dashlet to fetch, display, and add users via Nagios XI API"),
        DASHLET_COPYRIGHT => "Copyright (c) 2025 Nagios Enterprises LLC",
        DASHLET_LICENSE => "BSD",
        DASHLET_HOMEPAGE => "https://www.nagios.com",
        DASHLET_REFRESHRATE => 60,
        DASHLET_FUNCTION => "user_management_dashlet_func",
        DASHLET_TITLE => _("User Management Dashlet"),
        DASHLET_OUTBOARD_CLASS => "user_management_outboardclass",
        DASHLET_INBOARD_CLASS => "user_management_inboardclass",
        DASHLET_PREVIEW_CLASS => "user_management_previewclass",
        DASHLET_WIDTH => "600", 
        DASHLET_HEIGHT => "450", 
        DASHLET_OPACITY => "1.0"
    );

    register_dashlet($name, $args);
}

function user_management_dashlet_func($mode = DASHLET_MODE_PREVIEW, $id = "", $args = null)
{
    $output = "";

    switch ($mode) {
        case DASHLET_MODE_GETCONFIGHTML:
            // Show API token input for the user to provide their token
            ob_start();
            ?>
            <label for="api_token">API Token:</label>
            <input class="form-control" style="margin-bottom: 10px" id="api_token" name="api_token" value="<?= htmlspecialchars($args['api_token'] ?? '') ?>">
            <p>Go to the account tab to retrieve your API token.</p>
            <?php
            $output = ob_get_clean();
            break;

        case DASHLET_MODE_OUTBOARD:
        case DASHLET_MODE_INBOARD:
            // Display user list and add user form
            ob_start();
            ?>
            <h3>User Management</h3>
            <div id="userList">
                <?php
                // Ensure the API token is provided
                $api_token = $args['api_token'] ?? '';
                if ($api_token) {
                    // Fetch users from the API
                    $users = get_users_from_api($api_token);

                    // Sort users by user_id
                    usort($users, function ($a, $b) {
                        return $a['user_id'] <=> $b['user_id'];
                    });

                    if (!empty($users)) {
                        echo "<h4>Existing Users</h4><ul>";
                        foreach ($users as $user) {
                            echo "<li>" . htmlspecialchars($user['username']) . "</li>";
                        }
                        echo "</ul>";
                    } else {
                        echo "<p>No users found or error retrieving data.</p>";
                    }
                } else {
                    echo "<p>Please provide an API token.</p>";
                }
                ?>
            </div>
            <script>
                function refreshUserList() {
                    const xhr = new XMLHttpRequest();
                    xhr.open('GET', '<?= $_SERVER['PHP_SELF'] ?>?action=refresh_users&api_token=<?= urlencode($api_token) ?>', true);
                    xhr.onload = function () {
                        if (xhr.status === 200) {
                            const response = JSON.parse(xhr.responseText); // Parse JSON response
                            if (response.userList) {
                                document.getElementById('userList').innerHTML = `<h4>Existing Users</h4><ul>${response.userList}</ul>`; // Update user list
                            }
                            if (response.dropdownOptions) {
                                document.getElementById('user_id').innerHTML = `<option value="" disabled selected>Select User</option>` + response.dropdownOptions; // Add "Select User" option and update dropdown
                            }
                        } else {
                            document.getElementById('userList').innerHTML = '<p>Error loading users.</p>';
                        }
                    };
                    xhr.send();
                }
            </script>
            <?php
            // Check if API token is provided
            $api_token = $args['api_token'] ?? '';
            if ($api_token) {
                // Add buttons to trigger the modals
                ?>
                <button type="button" class="btn btn-primary" onclick="document.getElementById('addUserModal').style.display='block'">Add New User</button>
                <button type="button" class="btn btn-danger" onclick="document.getElementById('deleteUserModal').style.display='block'">Delete User</button>

                <!-- Add Users Modal -->
                <div id="addUserModal" style="display:none; position:fixed; top:50%; left:50%; transform:translate(-50%, -50%); background:#333; color:white; padding:20px; border:1px solid #555; z-index:1000; border-radius:5px;">
                    <h4 style="color:white;">Add New User</h4>
                    <form method="POST" action="">
                        <div class="form-group">
                            <label for="username">Username:</label>
                            <input type="text" class="form-control" id="username" name="username" required>
                        </div>
                        <div class="form-group">
                            <label for="password">Password:</label>
                            <input type="password" class="form-control" id="password" name="password" required>
                        </div>
                        <div class="form-group">
                            <label for="name">Full Name:</label>
                            <input type="text" class="form-control" id="name" name="name" required>
                        </div>
                        <div class="form-group">
                            <label for="email">Email:</label>
                            <input type="email" class="form-control" id="email" name="email" required>
                        </div>
                        <button type="submit" class="btn btn-primary" name="action" value="add_user">Add User</button>
                        <button type="button" class="btn btn-secondary" onclick="document.getElementById('addUserModal').style.display='none'">Cancel</button>
                    </form>
                </div>

                <!-- Delete Users Modal -->
                <div id="deleteUserModal" style="display:none; position:fixed; top:50%; left:50%; transform:translate(-50%, -50%); background:#333; color:white; padding:20px; border:1px solid #555; z-index:1000; border-radius:5px;">
                    <h4 style="color:white;">Delete User</h4>
                    <form method="POST" action="" onsubmit="return confirm('Are you sure you want to delete this user?');">
                        <div class="form-group">
                            <label for="user_id">Select User:</label>
                            <select class="form-control" id="user_id" name="user_id" required>
                                <option value="" disabled selected>Select User</option>
                                <?php 
                                $validUsersExist = false;
                                foreach ($users as $user): 
                                    if ($user['user_id'] != '1'): // Exclude user with user_id = 1
                                        $validUsersExist = true;
                                ?>
                                        <option value="<?= htmlspecialchars($user['user_id']) ?>"><?= htmlspecialchars($user['username']) ?></option>
                                <?php 
                                    endif; 
                                endforeach; 
                                if (!$validUsersExist): // Add placeholder if no valid users exist
                                ?>
                                    <option value="" disabled>No valid users available</option>
                                <?php endif; ?>
                            </select>
                        </div>
                        <button type="submit" class="btn btn-danger" name="action" value="delete_user">Delete User</button>
                        <button type="button" class="btn btn-secondary" onclick="document.getElementById('deleteUserModal').style.display='none'">Cancel</button>
                    </form>
                </div>

                <script>
                    // Close modal when clicking outside of it
                    window.onclick = function(event) {
                        const addModal = document.getElementById('addUserModal');
                        const deleteModal = document.getElementById('deleteUserModal');
                        if (event.target === addModal) {
                            addModal.style.display = 'none';
                        }
                        if (event.target === deleteModal) {
                            deleteModal.style.display = 'none';
                        }
                    }

                    function refreshDeleteDropdown() {
                        const xhr = new XMLHttpRequest();
                        xhr.open('GET', '<?= $_SERVER['PHP_SELF'] ?>?action=refresh_users&api_token=<?= urlencode($api_token) ?>', true);
                        xhr.onload = function () {
                            if (xhr.status === 200) {
                                const response = JSON.parse(xhr.responseText); // Parse JSON response
                                if (response.dropdownOptions) {
                                    document.getElementById('user_id').innerHTML = `<option value="" disabled selected>Select User</option>` + response.dropdownOptions; // Add "Select User" option and update dropdown
                                }
                            }
                        };
                        xhr.send();
                    }
                </script>
                <?php

                // Handle the form submission for adding a user
                if (isset($_POST['action']) && $_POST['action'] == 'add_user') {
                    $username = $_POST['username'] ?? '';
                    $password = $_POST['password'] ?? '';
                    $name = $_POST['name'] ?? '';
                    $email = $_POST['email'] ?? '';

                    $response = add_user_via_api($api_token, $username, $password, $name, $email);

                    if ($response === true) {
                        echo "<p>User has been added successfully!</p>";
                        echo "<script>refreshUserList();</script>"; // Refresh the user list dynamically
                    } else {
                        echo "<p>Error: $response</p>";
                    }
                }

                // Handle the form submission for deleting a user
                if (isset($_POST['action']) && $_POST['action'] == 'delete_user') {
                    $user_id = $_POST['user_id'] ?? '';

                    $response = delete_user_via_api($api_token, $user_id);

                    if ($response === true) {
                        echo "<p>User has been deleted successfully!</p>";
                        echo "<script>refreshUserList();</script>"; // Refresh the user list dynamically
                    } else {
                        echo "<p>Error: $response</p>";
                    }
                }
            } else {
                echo "<p>Please provide an API token.</p>";
            }
            $output = ob_get_clean();
            break;

        case DASHLET_MODE_PREVIEW:
            // Preview mode shows a simple image
            $imgbase = get_dashlet_url_base("user-management-dashlet");
            ob_start();
            ?>
            <img src='<?= $imgbase ?>/user-management-preview.png'>
            <?php
            $output = ob_get_clean();
            break;
    }

    return $output;
}

if (isset($_GET['action']) && $_GET['action'] === 'refresh_users') {
    // Ensure the API token is passed
    $api_token = $_GET['api_token'] ?? '';
    $response = ['userList' => '', 'dropdownOptions' => ''];

    if ($api_token) {
        $users = get_users_from_api($api_token);

        // Sort users by user_id
        usort($users, function ($a, $b) {
            return $a['user_id'] <=> $b['user_id'];
        });

        if (!empty($users)) {
            foreach ($users as $user) {
                $response['userList'] .= "<li>" . htmlspecialchars($user['username']) . "</li>"; // Build user list
                if ($user['user_id'] != '1') { // Exclude user with user_id = 1
                    $response['dropdownOptions'] .= "<option value=\"" . htmlspecialchars($user['user_id']) . "\">" . htmlspecialchars($user['username']) . "</option>";
                }
            }
        }

        // If no valid users for the dropdown, add a placeholder
        if (empty($response['dropdownOptions'])) {
            $response['dropdownOptions'] = "<option value=\"\" disabled>No valid users available</option>";
        }
    } else {
        $response['userList'] = "<li>Error: API token is missing</li>";
        $response['dropdownOptions'] = "<option value=\"\" disabled>Error: API token is missing</option>";
    }

    echo json_encode($response); // Return JSON response
    exit;
}

function get_users_from_api($api_token)
{
    // Get the Nagios server IP address
    $server_ip = get_nagios_server_ip();
    
    // Build the URL for the API request
    $url = "http://$server_ip/nagiosxi/api/v1/system/user?apikey=$api_token&pretty=1";

    // Use cURL to make the GET request to the API
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

    $response = curl_exec($ch);
    curl_close($ch);

    // If the request was successful, process the response
    if ($response) {
        $data = json_decode($response, true);
        
        // Check if the response contains the user data
        if (isset($data['users'])) {
            // Return an associative array with user IDs as keys and usernames as values
            return array_map(function($user) {
                return ['user_id' => $user['user_id'], 'username' => $user['username']]; // Assuming 'id' and 'username' are keys
            }, $data['users']);
        }
    }

    return [];  // Return an empty array if there was an issue
}

function add_user_via_api($api_token, $username, $password, $name, $email)
{
    // Get the Nagios server IP address
    $server_ip = get_nagios_server_ip();
    
    // Prepare POST data
    $data = [
        'username' => $username,
        'password' => $password,
        'name' => $name,
        'email' => $email
    ];

    // Build the URL for the API request
    $url = "http://$server_ip/nagiosxi/api/v1/system/user?apikey=$api_token&pretty=1";

    // Use cURL to make the POST request to add the user
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($data));

    $response = curl_exec($ch);
    curl_close($ch);

    // If the request was successful
    if ($response) {
        $data = json_decode($response, true);
        if (isset($data['error'])) {
            return "API Error: " . $data['error'];
        }
        return true;  // Return true if the user was added successfully
    }

    return "Error: Unable to communicate with the API.";  // Return error message if something went wrong
}

function delete_user_via_api($api_token, $user_id)
{
    // Get the Nagios server IP address
    $server_ip = get_nagios_server_ip();

    // Build the URL for the API request
    $url = "http://$server_ip/nagiosxi/api/v1/system/user/$user_id?apikey=$api_token&pretty=1";

    // Initialize cURL
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "DELETE");  // Set method to DELETE

    // Execute the cURL request
    $response = curl_exec($ch);
    curl_close($ch);

    // Check if the request was successful
    if ($response) {
        $data = json_decode($response, true);
        
        // Check if the response contains an error
        if (isset($data['error'])) {
            return "API Error: " . $data['error'];
        }
        
        return true;  // Return true if the user was deleted successfully
    }

    return "Error: Unable to communicate with the API.";  // Return error message if something went wrong
}

function get_nagios_server_ip() {
    // Get the local IP address using `hostname -I`
    $ip = trim(shell_exec("hostname -I"));
    return $ip;
}
?>
