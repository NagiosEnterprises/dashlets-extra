<?php
//
// Dashlet to show down hosts in Nagios XI
//

include_once(dirname(__FILE__).'/../dashlethelper.inc.php');

// Run initiation
down_hosts_dashlet_init();

function down_hosts_dashlet_init()
{
    $name = "down_hosts_dashlet";

    $args = array(
        DASHLET_NAME => $name,
        DASHLET_VERSION => "1.0.0",
        DASHLET_DATE => "01/29/25",
        DASHLET_AUTHOR => "Nagios Enterprises LLC",
        DASHLET_DESCRIPTION => _("Dashlet to show down hosts in Nagios XI"),
        DASHLET_COPYRIGHT => "Copyright (c) 2025 Nagios Enterprises LLC",
        DASHLET_LICENSE => "BSD",
        DASHLET_HOMEPAGE => "https://www.yourcompany.com",
        DASHLET_REFRESHRATE => 60,
        DASHLET_FUNCTION => "down_hosts_dashlet_func",
        DASHLET_TITLE => _("Down Hosts Dashlet"),
        DASHLET_OUTBOARD_CLASS => "down_hosts_outboardclass",
        DASHLET_INBOARD_CLASS => "down_hosts_inboardclass",
        DASHLET_PREVIEW_CLASS => "down_hosts_previewclass",
        DASHLET_WIDTH => "300", 
        DASHLET_HEIGHT => "200", 
        DASHLET_OPACITY => "1.0"
    );

    register_dashlet($name, $args);  
}

function down_hosts_dashlet_func($mode = DASHLET_MODE_PREVIEW, $id = "", $args = null)
{
    $output = "";

    switch ($mode) {
        case DASHLET_MODE_GETCONFIGHTML:
            // Need to grab API token from user
            ob_start();
            ?>
            <label for="api_token">API Token:</label>
            <input class="form-control" style="margin-bottom: 10px" id="api_token" name="api_token" value="<?= htmlspecialchars($args['api_token'] ?? '') ?>">
            <p>Go to the account tab to retrieve your API token.</p>
            <?php
            $output = ob_get_clean();
            break;

        case DASHLET_MODE_OUTBOARD:
        case DASHLET_MODE_INBOARD:
            // Fetch the down hosts
            $down_hosts = get_down_hosts($args['api_token'] ?? '');
            $server_ip = get_local_ip(); // Dynamically grab the IP address

            // Output the down hosts
            ob_start();
            echo "<h3>Down Hosts</h3>";
            if (count($down_hosts) > 0) {
                echo "<div style='height: calc(100% - 50px); overflow-y: auto;'>"; // Adjust height dynamically
                echo "<ul>";
                foreach ($down_hosts as $host) {
                    $url = "http://$server_ip/nagiosxi/includes/components/xicore/status.php?show=hostdetail&host=$host"; // Use dynamic IP address
                    echo "<li><div style='border: 1px solid red; background-color: red; padding: 5px; margin: 5px;'><a href='" . htmlspecialchars($url) . "' style='color: white;'>" . htmlspecialchars($host) . "</a></div></li>";
                }
                echo "</ul>";
                echo "</div>";
            } else {
                echo "<p>Everything is up.</p>";
            }
            $output = ob_get_clean();
            break;

        case DASHLET_MODE_PREVIEW:
            // Preview mode shows a simple image or placeholder
            $imgbase = get_dashlet_url_base("down-hosts-dashlet");
            ob_start();
            ?>
            <img src='<?= $imgbase ?>/down-hosts-preview.png'>
            <?php
            $output = ob_get_clean();
            break;
    }

    return $output;
}

function get_local_ip() {
    // Get local IP address using the `hostname -I` command
    $ip = trim(shell_exec("hostname -I"));
    return $ip;
}

function get_down_hosts($api_token)
{
    // We want to grab the ip address from the Nagios Host
    $server_ip = get_local_ip();
    // Example: Fetch host data from Nagios XI API
    $url = "http://$server_ip/nagiosxi/api/v1/objects/hoststatus?apikey=$api_token&pretty=1";

    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

    $response = curl_exec($ch);
    curl_close($ch);
    // echo $response;

    // Check if we got a valid response
    if ($response) {
        $data = json_decode($response, true);
        $down_hosts = [];

        // Filter for down hosts
        foreach ($data['hoststatus'] as $host) {
            if ($host['current_state'] == 1) { // 1 appears to mean down in Nagios
                $down_hosts[] = $host['host_name'];
            }
        }

        // Sort the down hosts alphabetically
        sort($down_hosts);

        return $down_hosts;
    } else {
        return [];  // Return an empty array if API request fails
    }
}
